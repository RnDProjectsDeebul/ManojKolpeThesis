# MAS project proposal [![Build Status](https://travis-ci.org/mas-group/project-proposal.svg?branch=master)](https://travis-ci.org/mas-group/project-proposal)


Please make sure to change name of the file to match the naming convention, e.g. `DoeJ-RnDProposal.tex`
